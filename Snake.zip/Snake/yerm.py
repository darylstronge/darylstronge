import random

my_string = 'monty python'

my_list = [letter + "*" for letter in my_string]

print(my_list)