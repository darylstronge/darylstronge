'''
    Project Name: DoubleSnake
    Author: Daryl Stronge & Lainey
    Date created: 10/15/2016
    Period 6
	
	Pygame Download: http://www.pygame.org/download.shtml
'''

import pygame
import time
import random
import sys
from time import sleep


def snake(block_size, snakelist): #Function used to create first snake
    for XnY in snakelist:
        pygame.draw.rect(gameDisplay, player1Color, [XnY[0],XnY[1],block_size,block_size])

def snake2(block_size, snakelist): #Function used to create second snake
    for XnY in snakelist:
        pygame.draw.rect(gameDisplay, player2Color, [XnY[0],XnY[1],block_size,block_size])

def text_objects(text,color): #Creates text
    textSurface = font.render(text, True, color)
    return textSurface, textSurface.get_rect()


def message_to_screen(msg,color): #Displays message
    textSurf, textRect = text_objects(msg,color)
    textRect.center = (display_width / 2), (display_height / 2)
    gameDisplay.blit(textSurf, textRect)


def start(): #Instruction Prompt
    print("Welcome to DoubleSnake. This is a two player version of the popular game snake.")
    print(" ")
    sleep(3)
    print("The goal is to beat your opponent by making them crash into you or having them go off of the game screen.")
    print("However, if the heads of both snakes collide with each other, the snake with the longest length will be the "
          "winner.")
    print(" ")
    sleep(6)
    print("Player 1 is indicated by the blue square on the game screen.")
    print("Player 1 will use the arrow keys to move.")
    print(" ")
    sleep(4)
    print("Player 2 is indicated by the purple square on the game screen.")
    print("Player 2 will use the W, A, S, and D keys to move")
    print(" ")
    sleep(4)
    print("Eating the apple indicated by the red square will make the snake grow.")
    print(" ")
    sleep(3)
    print("Stay away from the black border on the sides of the screen.")
    print("Touching the border will result in a loss.")
    print(" ")
    sleep(3)
    

def gameLoop():
    gameExit = False #if true game closes
    gameOver = False #if true game ends

    #-----MOVEMENT VARIABLES-----#
    goingLeft = False
    goingRight = False
    goingUp = False
    goingDown = False    
    
    goingLeft2 = False
    goingRight2 = False
    goingUp2 = False
    goingDown2 = False  
    #-----MOVEMENT VARIABLES-----#

    #-----SNAKE POSITION VARIABLES-----#
    lead_x = display_width/2
    lead_y = display_height/2

    lead_x_2 = display_width/4
    lead_y_2 = display_height/4

    lead_x_change = 0
    lead_y_change = 0

    lead_x_change_2 = 0
    lead_y_change_2 = 0

    snakeList = []
    snakeLength = 1

    snakeList2 = []
    snakeLength2 = 1
    #-----SNAKE POSITION VARIABLES-----#

    randAppleX = round(random.randrange(30, 770))#/10.0)*10.0
    randAppleY = round(random.randrange(30, 570))#/10.0)*10.0

    while not gameExit:

        while gameOver == True:
            gameDisplay.fill(white)
            message_to_screen("Game over, press C to play again or Q to quit", red)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    gameOver = False
                    gameExit = True

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        gameExit = True
                        gameOver = False
                    if event.key == pygame.K_c:
                        gameLoop()


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameExit = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    if goingRight == False and snakeLength > 1:
                        goingLeft = True
                        goingUp = False
                        goingDown = False
                        lead_x_change = -block_size
                        lead_y_change = 0
                    elif snakeLength == 1:
                        lead_x_change = -block_size
                        lead_y_change = 0
                if event.key == pygame.K_RIGHT :
                    if goingLeft == False and snakeLength > 1:
                        print("ex")
                        goingRight = True
                        goingUp = False
                        goingDown = False
                        lead_x_change = block_size
                        lead_y_change = 0
                    elif snakeLength == 1:
                        lead_x_change = block_size
                        lead_y_change = 0 
                if event.key == pygame.K_UP:
                    if goingDown == False and snakeLength > 1:
                        goingRight = False
                        goingUp = True
                        goingLeft = False
                        lead_y_change = -block_size
                        lead_x_change = 0
                    elif snakeLength == 1:
                        lead_y_change = -block_size
                        lead_x_change = 0
                if event.key == pygame.K_DOWN:
                    if goingUp == False and snakeLength > 1:
                        goingRight = False
                        goingDown = True
                        goingLeft = False
                        lead_y_change = block_size
                        lead_x_change = 0
                    elif snakeLength == 1:
                        lead_y_change = block_size
                        lead_x_change = 0


                if event.key == pygame.K_w:
                    if goingDown2 == False and snakeLength2 > 1:
                        goingRight2 = False
                        goingUp2 = True
                        goingLeft2 = False
                        lead_y_change_2 = -10
                        lead_x_change_2 = 0
                    elif snakeLength2 == 1:
                        lead_y_change_2 = -10
                        lead_x_change_2 = 0
                if event.key == pygame.K_s:
                    if goingUp2 == False and snakeLength2 > 1:
                        goingRight2 = False
                        goingDown2 = True
                        goingLeft2 = False
                        lead_y_change_2 = 10
                        lead_x_change_2 = 0
                    elif snakeLength2  == 1:
                        lead_y_change_2 = 10
                        lead_x_change_2 = 0
                if event.key == pygame.K_d:
                    if goingLeft2 == False and snakeLength2 > 1:
                        goingRight2 = True
                        goingDown2 = False
                        goingUp2 = False
                        lead_y_change_2 = 0
                        lead_x_change_2 = 10
                    elif snakeLength2 == 1:
                        lead_y_change_2 = 0
                        lead_x_change_2 = 10
                if event.key == pygame.K_a:
                    if goingRight2 == False and snakeLength2 > 1:
                        goingLeft2 = True
                        goingDown2 = False
                        goingUp2 = False
                        lead_y_change_2 = 0
                        lead_x_change_2 = -10
                    elif snakeLength2 == 1:
                        lead_y_change_2 = 0
                        lead_x_change_2 = -10

        if lead_x >= 775 or lead_x < 20 or lead_y >= 575 or lead_y < 20: #IF PLAYER 1 HITS THE BORDER
            message_to_screen("PLAYER 1 HIT THE BORDER", red)
            pygame.display.update()
            pygame.time.delay(1000)
            gameDisplay.fill(white)
            message_to_screen("Player 2 wins!", player2Color)
            pygame.display.update()
            pygame.time.delay(3000)
            gameOver = True

        if lead_x_2 >= 775 or lead_x_2 < 20 or lead_y_2 >= 575 or lead_y_2 < 20: #IF PLAYER 2 HITS THE BORDER
            message_to_screen("PLAYER 2 HIT THE BORDER", red)
            pygame.display.update()
            pygame.time.delay(1000)
            gameDisplay.fill(white)
            message_to_screen("Player 1 wins!", player1Color)
            pygame.display.update()
            pygame.time.delay(3000)
            gameOver = True

        #-----SNAKE MOVEMENT-----#
        lead_x += lead_x_change
        lead_y += lead_y_change

        lead_x_2 += lead_x_change_2
        lead_y_2 += lead_y_change_2
        #-----SNAKE MOVEMENT-----#

        gameDisplay.fill(white) #DISPLAY BACKGROUND

        #-----BORDERS-----#
        pygame.draw.rect(gameDisplay, black, [0, 0, 20, 1000])
        pygame.draw.rect(gameDisplay, black, [780, 0, 20, 1000])
        pygame.draw.rect(gameDisplay, black, [0, 0, 1000, 20])
        pygame.draw.rect(gameDisplay, black, [0, 580, 1000, 20])
        #-----BORDERS-----#

        #-----PLAYERSCORES-----#
        player1Score = font.render(str(snakeLength), 1, player1Color)
        gameDisplay.blit(player1Score, (5, 5)) #Display length of Player 1's snake
        player2Score = font.render(str(snakeLength2), 1, player2Color)
        gameDisplay.blit(player2Score, (750, 5)) #Display length of Player 2's snake
        #-----PLAYERSCORES-----#

        AppleThickness = 15#APPLE SIZE
        pygame.draw.rect(gameDisplay, red, [randAppleX, randAppleY, AppleThickness, AppleThickness]) #PLACES APPLE ON DISPLAY

        #-----DISPLAYS SNAKES-----#
        snakeHead = []
        snakeHead.append(lead_x)
        snakeHead.append(lead_y)
        snakeList.append(snakeHead)

        snakeHead2 = []
        snakeHead2.append(lead_x_2)
        snakeHead2.append(lead_y_2)
        snakeList2.append(snakeHead2)
        #-----DISPLAYS SNAKES-----#

        if len(snakeList) > snakeLength:
            del snakeList[0]

        if len(snakeList2) > snakeLength2:
            del snakeList2[0]

        for eachSegment in snakeList[:-1]: #CHECKS IF SNAKE1 IS TOUCHING ITSELF
            if eachSegment == snakeHead:
                gameOver = True

        for eachSegment in snakeList2[:-1]: #CHECKS IF SNAKE2 IS TOUCHING ITSELF
            if eachSegment == snakeHead2:
                message_to_screen("PLAYER 2 BUMPED INTO THEMSELVES", red)
                pygame.display.update()
                pygame.time.delay(1000)
                gameDisplay.fill(white)
                message_to_screen("Player 1 wins!", player1Color)
                pygame.display.update()
                pygame.time.delay(3000)
                gameOver = True

        if snakeHead == snakeHead2: #IF BOTH SNAKES COLLIDE HEAD ON
            gameDisplay.fill(white)
            message_to_screen("BOTH PLAYERS COLLIDED HEAD ON.", red)
            pygame.display.update()
            pygame.time.delay(1000)
            gameDisplay.fill(white)

            if snakeLength > snakeLength2:
                message_to_screen("Player 1 wins!", player1Color)
            elif snakeLength2 > snakeLength:
                message_to_screen("Player 2 wins!", player2Color)
            else:
                message_to_screen("It's a tie!", neutralColor)

            pygame.display.update()
            pygame.time.delay(3000)
            gameOver = True

        for eachSegment in snakeList[:-1]: #IF THE HEAD OF SNAKE 2 BUMPS INTO THE BODY OF SNAKE 1
            if eachSegment == snakeHead2:
                message_to_screen("PLAYER 2 CRASHED INTO PLAYER 1.", red)
                pygame.display.update()
                pygame.time.delay(1000)
                gameDisplay.fill(white)
                message_to_screen("Player 1 wins!", player1Color)
                pygame.display.update()
                pygame.time.delay(3000)
                gameOver = True

        snake(block_size, snakeList) #MOVES SNAKE1 TO NEW COORDINATES

        snake2(block_size, snakeList2) #MOVES SNAKE2 TO NEW COORDINATES

        pygame.display.update() #UPDATES SCREEN

        if lead_x > randAppleX and lead_x < randAppleX + AppleThickness or lead_x + block_size > randAppleX and lead_x + block_size < randAppleX + AppleThickness:
            #IF PLAYER 1'S COORIDINATES ARE THE SAME AS THE APPLE
            if lead_y > randAppleY and lead_y < randAppleY + AppleThickness:

                randAppleX = round(random.randrange(30, 770))#GENERATE NEW APPLE COORDINATES
                randAppleY = round(random.randrange(30, 570))
                snakeLength += 1 #INCREASE SCORE

            elif lead_y + block_size > randAppleY and lead_y + block_size < randAppleY + AppleThickness:

                randAppleX = round(random.randrange(30, 770))#GENERATE NEW APPLE COORDINATES
                randAppleY = round(random.randrange(30, 570))
                snakeLength += 1 #INCREASE SCORE

        if lead_x_2 > randAppleX and lead_x_2 < randAppleX + AppleThickness or lead_x_2 + block_size > randAppleX and lead_x_2 + block_size < randAppleX + AppleThickness:
            #IF PLAYER 1'S COORIDINATES ARE THE SAME AS THE APPLE
            if lead_y_2 > randAppleY and lead_y_2 < randAppleY + AppleThickness:

                randAppleX = round(random.randrange(30, 770))#GENERATE NEW APPLE COORDINATES
                randAppleY = round(random.randrange(30, 570))
                snakeLength2 += 1#INCREASE SCORE

            elif lead_y_2 + block_size > randAppleY and lead_y_2 + block_size < randAppleY + AppleThickness:

                randAppleX = round(random.randrange(30, 770))#GENERATE NEW APPLE COORDINATES
                randAppleY = round(random.randrange(30, 570))
                snakeLength2 += 1#INCREASE SCORE









        clock.tick(FPS) #FRAMERATE

    pygame.quit()
    quit()

start()
pygame.init()



#-----COLORS-----#
player1Color = (0,255,255)
player2Color = (255,0,255)
neutralColor = (255,125,2)
white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
green = (0,155,0)
blue = (0, 0, 255)
#-----COLORS-----#

display_width = 800 #Window width
display_height  = 600 #Window Height

gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption('Slither')



clock = pygame.time.Clock()

block_size = 10 #Snake Size
FPS = 25 #Framerate

font = pygame.font.SysFont(None, 40) #Font used
gameLoop()