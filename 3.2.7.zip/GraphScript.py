import matplotlib.pyplot as plt
import numpy as np
import os.path

def scrapeData(start, stop, sizeList):
    '''
    Data from:
    "Predicting Adult Smoking: The Influence of Smoking During
    Adolescence and Smoking Among Friends and Family"
    
    http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.516.1774&rep=rep1&type=pdf
    (Page 5)
    '''
    for line in data[start:stop]:
        if "Mother's Smoking" in line:
            filler, decimal, filler2 = line.split(',')
            decimal = round(float(decimal), 2)
            percentage = int(decimal * 100)
            sizeList.append(percentage)
            
            
        elif "Father's Smoking" in line:
            filler, decimal, filler2 = line.split(',')
            decimal = round(float(decimal), 2)
            percentage = int(decimal * 100)
            sizeList.append(percentage)
   
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'smoking stats.csv')
datafile = open(filename,'r')
data = datafile.readlines()

bar1Sizes = []
bar2Sizes = []
colors = ['k', '#D2942F']
scrapeData(33,38, bar1Sizes)
scrapeData(13,18, bar2Sizes)
objects = ('Mother of smoker', 'Father of smoker')
y_pos = np.arange(len(objects))

plt.subplots(2, figsize=(8, 8)) #2 figures to be made

plt.subplot(211) #Graph 1
plt.bar(y_pos, bar1Sizes, align='center', color=colors)
plt.xticks(y_pos, objects)
plt.ylabel("% of sample that smokes")
plt.title("Odds ratios of smoking among 28 year olds in relation to parents' smoking", fontsize=12)
plt.rcParams['axes.facecolor'] = 'r' #Graph Background
axes = plt.gca()
axes.set_ylim([0,100]) #Y axis limits

plt.subplot(212) #Graph 2
plt.bar(y_pos, bar2Sizes, align='center', color=colors)
plt.xticks(y_pos, objects)
plt.ylabel("% of sample that smokes")
plt.title("Odds ratios of smoking among 15 year olds in relation to parents' smoking", fontsize=12)

axes = plt.gca()
axes.set_ylim([0,100])

plt.show()

